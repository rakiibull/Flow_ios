import Foundation
import SwiftUI
import WebKit

struct YouTubeVideo: Identifiable, Hashable, Codable {
    let id: String
    let title: String
    let channelTitle: String
    let thumbnailURL: URL?

    enum CodingKeys: String, CodingKey {
        case id, snippet
    }

    enum IDKeys: String, CodingKey {
        case videoId
    }

    enum SnippetKeys: String, CodingKey {
        case title, channelTitle, thumbnails
    }

    enum ThumbnailKeys: String, CodingKey {
        case high, medium, defaults = "default"
    }

    enum ThumbnailValueKeys: String, CodingKey {
        case url
    }

    init(id: String, title: String, channelTitle: String, thumbnailURL: URL?) {
        self.id = id
        self.title = title
        self.channelTitle = channelTitle
        self.thumbnailURL = thumbnailURL
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        let idContainer = try container.nestedContainer(keyedBy: IDKeys.self, forKey: .id)
        id = try idContainer.decode(String.self, forKey: .videoId)
        let snippet = try container.nestedContainer(keyedBy: SnippetKeys.self, forKey: .snippet)
        title = try snippet.decode(String.self, forKey: .title)
        channelTitle = try snippet.decode(String.self, forKey: .channelTitle)
        let thumbnails = try snippet.nestedContainer(keyedBy: ThumbnailKeys.self, forKey: .thumbnails)
        let image = (try? thumbnails.nestedContainer(keyedBy: ThumbnailValueKeys.self, forKey: .high))
            ?? (try? thumbnails.nestedContainer(keyedBy: ThumbnailValueKeys.self, forKey: .medium))
            ?? (try? thumbnails.nestedContainer(keyedBy: ThumbnailValueKeys.self, forKey: .defaults))
        thumbnailURL = try image?.decode(URL.self, forKey: .url)
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        var idContainer = container.nestedContainer(keyedBy: IDKeys.self, forKey: .id)
        try idContainer.encode(id, forKey: .videoId)
        var snippet = container.nestedContainer(keyedBy: SnippetKeys.self, forKey: .snippet)
        try snippet.encode(title, forKey: .title)
        try snippet.encode(channelTitle, forKey: .channelTitle)
        var thumbnails = snippet.nestedContainer(keyedBy: ThumbnailKeys.self, forKey: .thumbnails)
        if let thumbnailURL {
            var image = thumbnails.nestedContainer(keyedBy: ThumbnailValueKeys.self, forKey: .medium)
            try image.encode(thumbnailURL, forKey: .url)
        }
    }
}

private struct YouTubeSearchResponse: Decodable {
    let items: [YouTubeVideo]
}

private struct YouTubeAPIErrorResponse: Decodable {
    struct APIError: Decodable {
        struct Item: Decodable {
            let message: String
        }
        let errors: [Item]?
        let message: String?
    }
    let error: APIError
}

private enum YouTubeSearchError: LocalizedError {
    case missingKey
    case invalidResponse
    case api(String)

    var errorDescription: String? {
        switch self {
        case .missingKey:
            return "Add a YouTube Data API v3 key in Settings to search videos."
        case .invalidResponse:
            return "YouTube returned an unexpected response. Please try again."
        case .api(let message):
            return message
        }
    }
}

private enum YouTubeDataService {
    static func search(query: String, apiKey: String) async throws -> [YouTubeVideo] {
        let key = apiKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { throw YouTubeSearchError.missingKey }
        guard var components = URLComponents(string: "https://www.googleapis.com/youtube/v3/search") else {
            throw YouTubeSearchError.invalidResponse
        }
        components.queryItems = [
            URLQueryItem(name: "part", value: "snippet"),
            URLQueryItem(name: "type", value: "video"),
            URLQueryItem(name: "videoEmbeddable", value: "true"),
            URLQueryItem(name: "maxResults", value: "25"),
            URLQueryItem(name: "q", value: query),
            URLQueryItem(name: "key", value: key)
        ]
        guard let url = components.url else { throw YouTubeSearchError.invalidResponse }
        var request = URLRequest(url: url)
        request.timeoutInterval = 25
        request.setValue("org.flowtube.flow.ios", forHTTPHeaderField: "X-Ios-Bundle-Identifier")
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw YouTubeSearchError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else {
            let message = (try? JSONDecoder().decode(YouTubeAPIErrorResponse.self, from: data).error.message)
                ?? "YouTube search failed (HTTP \(http.statusCode)). Check the API key and API quota."
            throw YouTubeSearchError.api(message)
        }
        return try JSONDecoder().decode(YouTubeSearchResponse.self, from: data).items
    }
}

struct YouTubeSearchSheet: View {
    let apiKey: String
    @Environment(\.dismiss) private var dismiss
    @State private var query = ""
    @State private var results: [YouTubeVideo] = []
    @State private var isLoading = false
    @State private var errorMessage: String?

    var body: some View {
        NavigationStack {
            VStack(spacing: 12) {
                HStack(spacing: 10) {
                    TextField("Search YouTube videos", text: $query)
                        .textFieldStyle(.roundedBorder)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .submitLabel(.search)
                        .onSubmit { Task { await runSearch() } }
                    Button("Search") { Task { await runSearch() } }
                        .disabled(query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || isLoading)
                }
                .padding(.horizontal, 14)
                if isLoading {
                    ProgressView("Searching YouTube…").frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if let errorMessage {
                    ContentUnavailableView("Search unavailable", systemImage: "exclamationmark.magnifyingglass", description: Text(errorMessage))
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if results.isEmpty {
                    ContentUnavailableView("Search YouTube", systemImage: "play.rectangle", description: Text("Search results appear here in Flow. Tap a video to watch it in the app."))
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    ScrollView {
                        LazyVStack(spacing: 16) {
                            ForEach(results) { video in
                                NavigationLink(value: video) {
                                    YouTubeResultCard(video: video)
                                }
                                .buttonStyle(.plain)
                            }
                        }
                        .padding(.horizontal, 14)
                        .padding(.bottom, 20)
                    }
                }
            }
            .padding(.top, 12)
            .background(Color.black)
            .navigationTitle("YouTube videos")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Done") { dismiss() } } }
            .navigationDestination(for: YouTubeVideo.self) { YouTubePlayerScreen(video: $0) }
        }
        .preferredColorScheme(.dark)
    }

    @MainActor
    private func runSearch() async {
        let text = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        isLoading = true
        errorMessage = nil
        do {
            results = try await YouTubeDataService.search(query: text, apiKey: apiKey)
            if results.isEmpty { errorMessage = "No embeddable videos were found for this search." }
        } catch {
            errorMessage = error.localizedDescription
        }
        isLoading = false
    }
}

private struct YouTubeResultCard: View {
    let video: YouTubeVideo

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            AsyncImage(url: video.thumbnailURL) { phase in
                if let image = phase.image {
                    image.resizable().scaledToFill()
                } else {
                    Rectangle().fill(Color.white.opacity(0.1)).overlay(Image(systemName: "play.rectangle.fill").font(.title).foregroundStyle(.white.opacity(0.65)))
                }
            }
            .frame(width: 142, height: 86)
            .clipShape(RoundedRectangle(cornerRadius: 10))
            VStack(alignment: .leading, spacing: 6) {
                Text(video.title).font(.subheadline.weight(.semibold)).foregroundStyle(.white).lineLimit(3)
                Text(video.channelTitle).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                Label("Watch in Flow", systemImage: "play.fill").font(.caption2).foregroundStyle(.white.opacity(0.8))
            }
            Spacer(minLength: 0)
        }
        .padding(10)
        .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 14))
        .contentShape(Rectangle())
    }
}

private struct YouTubePlayerScreen: View {
    let video: YouTubeVideo

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                YouTubeEmbeddedPlayer(videoID: video.id)
                    .frame(height: 220)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                Text(video.title).font(.title3.bold())
                Text(video.channelTitle).font(.subheadline).foregroundStyle(.secondary)
                Text("Playback is provided by YouTube's embedded player.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            .padding(16)
        }
        .background(Color.black)
        .navigationTitle("Now playing")
        .navigationBarTitleDisplayMode(.inline)
    }
}

private struct YouTubeEmbeddedPlayer: UIViewRepresentable {
    let videoID: String

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.allowsInlineMediaPlayback = true
        configuration.mediaTypesRequiringUserActionForPlayback = []
        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.isOpaque = false
        webView.backgroundColor = .black
        webView.scrollView.isScrollEnabled = false
        webView.scrollView.backgroundColor = .black
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        let escapedID = videoID.addingPercentEncoding(withAllowedCharacters: .alphanumerics) ?? videoID
        let html = """
        <!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"></head>
        <body style="margin:0;background:#000;display:flex;align-items:center;justify-content:center;height:100vh">
        <iframe width="100%" height="100%" src="https://www.youtube.com/embed/\(escapedID)?playsinline=1&controls=1&autoplay=0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        </body></html>
        """
        webView.loadHTMLString(html, baseURL: URL(string: "https://www.youtube.com"))
    }
}
