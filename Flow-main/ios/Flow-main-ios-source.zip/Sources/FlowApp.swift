import SwiftUI
import AVKit
import WebKit

@main
struct FlowApp: App {
    var body: some Scene { WindowGroup { FlowRootView() } }
}

private enum FlowTab: String, CaseIterable {
    case home = "Home", shorts = "Shorts", music = "Music", subs = "Subs", library = "Library"
    var icon: String {
        switch self {
        case .home: "house.fill"
        case .shorts: "play.rectangle.on.rectangle"
        case .music: "music.note"
        case .subs: "rectangle.stack"
        case .library: "play.square.stack"
        }
    }
}

@MainActor struct FlowRootView: View {
    @StateObject private var store = FlowLocalStore()
    @State private var tab: FlowTab = .home
    @State private var selectedVideo: FlowItem?
    @State private var showSearch = false
    @State private var showSettings = false
    @State private var youtubeQuery = ""
    @State private var youtubeSearchURL: URL?

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 0) {
                header
                Group {
                    switch tab {
                    case .home: home
                    case .shorts: shorts
                    case .music: music
                    case .subs: subscriptions
                    case .library: library
                    }
                }.frame(maxWidth: .infinity, maxHeight: .infinity)
                tabBar
            }
        }
        .preferredColorScheme(.dark)
        .sheet(item: $selectedVideo) { item in
            DemoPlayer(video: item, store: store).presentationDragIndicator(.visible).presentationBackground(.black)
        }
        .sheet(isPresented: $showSearch) {
            NavigationStack {
                VStack(spacing: 12) {
                    HStack(spacing: 10) {
                        TextField("Search YouTube videos", text: $youtubeQuery)
                            .textFieldStyle(.roundedBorder)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .submitLabel(.search)
                            .onSubmit(openYouTubeSearch)
                        Button("Search", action: openYouTubeSearch)
                    }
                    if let youtubeSearchURL {
                        YouTubeWebView(url: youtubeSearchURL).id(youtubeSearchURL).frame(maxWidth: .infinity, maxHeight: .infinity)
                    } else {
                        ContentUnavailableView("Search YouTube", systemImage: "play.rectangle", description: Text("Search results and video playback will open here from YouTube."))
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                    }
                }
                .padding(.horizontal, 12)
                .background(Color.black)
                .navigationTitle("YouTube")
                .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Done") { showSearch = false } } }
            }.preferredColorScheme(.dark)
        }
        .sheet(isPresented: $showSettings) { settingsSheet.presentationDetents([.medium, .large]).presentationDragIndicator(.visible) }
    }

    private var header: some View {
        HStack {
            Text("◩ FLOW").font(.system(size: 22, weight: .heavy, design: .rounded))
            Spacer()
            Button { showSearch = true } label: { Image(systemName: "magnifyingglass") }
            Button { tab = .subs } label: { Image(systemName: "bell") }
            Button { showSettings = true } label: { Image(systemName: "gearshape") }
        }.font(.system(size: 19, weight: .medium)).foregroundStyle(.white).padding(.horizontal, 18).padding(.vertical, 13)
    }

    private func openYouTubeSearch() {
        let query = youtubeQuery.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !query.isEmpty,
              var components = URLComponents(string: "https://www.youtube.com/results") else { return }
        components.queryItems = [URLQueryItem(name: "search_query", value: query)]
        youtubeSearchURL = components.url
    }

    private var home: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 9) {
                        ForEach(["All", "Animation", "Technology", "Nature", "Music", "Art"], id: \.self) { category in
                            Button { store.selectedCategory = category } label: {
                                Text(category).font(.subheadline.weight(.medium)).padding(.horizontal, 15).padding(.vertical, 9)
                                    .background(store.selectedCategory == category ? Color.white.opacity(0.25) : Color.white.opacity(0.07), in: Capsule())
                            }.buttonStyle(.plain)
                        }
                    }
                }
                ForEach(store.rankedFeed) { item in
                    Button { selectedVideo = item } label: { VideoCard(item: item, saved: store.savedItems.contains(item)) }
                        .buttonStyle(.plain).contextMenu { itemActions(item) }
                }
                if !store.historyItems.isEmpty {
                    sectionTitle("Continue watching")
                    ForEach(store.historyItems) { item in
                        Button { selectedVideo = item } label: { VideoCard(item: item, saved: store.savedItems.contains(item)) }.buttonStyle(.plain)
                    }
                }
            }.padding(.horizontal, 16).padding(.bottom, 14)
        }
    }

    private var shorts: some View {
        ScrollView {
            VStack(spacing: 18) {
                Text("Shorts").font(.title2.bold()).frame(maxWidth: .infinity, alignment: .leading)
                ForEach(FlowItem.samples.filter(\.isShort)) { item in
                    Button { selectedVideo = item } label: {
                        ZStack(alignment: .bottomLeading) {
                            RoundedRectangle(cornerRadius: 22).fill(item.accent.gradient).frame(height: 420)
                                .overlay(Image(systemName: "play.fill").font(.system(size: 42)).foregroundStyle(.white.opacity(0.9)))
                            Text(item.title).font(.headline).padding(18)
                        }
                    }.buttonStyle(.plain).contextMenu { itemActions(item) }
                }
            }.padding(16)
        }
    }

    private var music: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text("Music").font(.largeTitle.bold())
                Text("Listen, explore, and manage your queue").foregroundStyle(.secondary)
                HStack(spacing: 14) {
                    RoundedRectangle(cornerRadius: 16).fill(.purple.gradient).frame(width: 92, height: 92).overlay(Image(systemName: "music.note").font(.largeTitle))
                    VStack(alignment: .leading, spacing: 6) { Text("Your music library").font(.headline); Text("Local music recommendations").font(.caption).foregroundStyle(.secondary) }
                }
                sectionTitle("Music picks for you")
                ForEach(store.rankedFeed.filter { $0.category == "Music" }) { item in
                    Button { selectedVideo = item } label: { VideoCard(item: item, saved: store.savedItems.contains(item)) }.buttonStyle(.plain).contextMenu { itemActions(item) }
                }
                sectionTitle("Queue · \(store.queueItems.count)")
                ForEach(store.queueItems) { item in
                    HStack {
                        Button { selectedVideo = item } label: { Text(item.title).lineLimit(1).frame(maxWidth: .infinity, alignment: .leading) }.buttonStyle(.plain)
                        Button { store.removeFromQueue(item) } label: { Image(systemName: "xmark.circle") }.buttonStyle(.plain)
                    }.padding(10).background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 12))
                }
                Label("Shuffle, repeat, lyrics — still to port", systemImage: "text.line.first.and.arrowtriangle.forward")
                    .font(.footnote).foregroundStyle(.secondary).padding(.vertical, 8)
            }.padding(16)
        }
    }

    private var subscriptions: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Subscriptions").font(.largeTitle.bold())
                Text("The original channel feed has not been connected yet.").foregroundStyle(.secondary)
                ForEach(store.rankedFeed) { item in
                    Button { selectedVideo = item } label: { VideoCard(item: item, saved: store.savedItems.contains(item)) }.buttonStyle(.plain)
                }
            }.padding(16)
        }
    }

    private var library: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Your Library").font(.largeTitle.bold())
                TextField("Search your library", text: $store.searchText).textFieldStyle(.roundedBorder)
                libraryRow("History · \(store.historyItems.count)", icon: "clock")
                libraryRow("Saved videos · \(store.savedItems.count)", icon: "bookmark")
                libraryRow("Your Taste · local profile", icon: "chart.xyaxis.line")
                if let url = store.exportProfile() {
                    ShareLink(item: url) { Label("Export local profile", systemImage: "square.and.arrow.up") }.font(.footnote)
                }
                tastePanel
                sectionTitle("Saved videos")
                ForEach(store.savedItems.filter { $0.title.localizedCaseInsensitiveContains(store.searchText) || store.searchText.isEmpty }) { item in
                    Button { selectedVideo = item } label: { VideoCard(item: item, saved: true) }.buttonStyle(.plain).contextMenu { itemActions(item) }
                }
                sectionTitle("Watch history")
                ForEach(store.historyItems) { item in
                    Button { selectedVideo = item } label: { VideoCard(item: item, saved: store.savedItems.contains(item)) }.buttonStyle(.plain)
                }
            }.padding(16)
        }
    }

    private var tastePanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Your Taste · Stored on this device").font(.headline)
            Text("FlowNeuro itself is not ported yet. This prototype learns simple topic weights from watches, likes, and saves.")
                .font(.footnote).foregroundStyle(.secondary)
            ProgressView(value: store.recommendationMaturity).tint(.white)
            Text("Local interactions: \(Int(store.recommendationMaturity * 40)) / 40").font(.caption).foregroundStyle(.secondary)
            ForEach(store.suggestedTopics) { entry in
                HStack { Text(entry.topic.capitalized); Spacer(); ProgressView(value: entry.value).frame(width: 100); Text("\(Int(entry.value * 100))%") }
                    .font(.caption)
            }
        }.padding(16).background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 18))
    }

    private var settingsSheet: some View {
        NavigationStack {
            Form {
                Section("Privacy") {
                    Label("Profile saved locally in this app's Application Support folder", systemImage: "iphone.and.arrow.forward")
                    Text("Your local profile stays on this device. YouTube search and playback load directly from YouTube in the in-app browser.")
                }
                Section("Recommendation profile") {
                    Text("Signals learned: \(Int(store.recommendationMaturity * 40))")
                    Button("Reset local profile", role: .destructive) { store.clearProfile() }
                }
                Section("Port status") { Text("Native UI and basic local learning are prototype-level. Streaming, downloads, lyrics, subtitles, SponsorBlock, casting and other Android services still need iOS implementations.") }
            }.navigationTitle("Settings").toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Done") { showSettings = false } } }
        }.preferredColorScheme(.dark)
    }

    @ViewBuilder private func itemActions(_ item: FlowItem) -> some View {
        Button { store.toggleSave(item) } label: { Label("Save / remove saved", systemImage: "bookmark") }
        Button { store.addToQueue(item) } label: { Label("Add to music queue", systemImage: "text.badge.plus") }
        Button { store.recordLike(item) } label: { Label("Like", systemImage: "hand.thumbsup") }
        Button { store.recordSkip(item) } label: { Label("Not interested", systemImage: "hand.thumbsdown") }
        Button { store.blockTopic(item) } label: { Label("Hide topic: \(item.category)", systemImage: "eye.slash") }
        Button { store.blockChannel(item) } label: { Label("Hide channel: \(item.channel)", systemImage: "person.crop.circle.badge.xmark") }
    }

    private var tabBar: some View {
        HStack {
            ForEach(FlowTab.allCases, id: \.self) { item in
                Button { tab = item } label: {
                    VStack(spacing: 5) { Image(systemName: item.icon).font(.system(size: 19, weight: .semibold)); Text(item.rawValue).font(.caption2) }
                        .foregroundStyle(tab == item ? .white : .gray).frame(maxWidth: .infinity).padding(.top, 10).padding(.bottom, 5)
                }.buttonStyle(.plain)
            }
        }.background(.ultraThinMaterial)
    }

    private func sectionTitle(_ title: String) -> some View { Text(title).font(.headline).padding(.top, 6) }
    private func libraryRow(_ title: String, icon: String) -> some View {
        HStack { Image(systemName: icon).frame(width: 28); Text(title); Spacer(); Image(systemName: "chevron.right").font(.caption).foregroundStyle(.secondary) }
            .padding(14).background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 14))
    }
}

private struct VideoCard: View {
    let item: FlowItem
    let saved: Bool
    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            ZStack(alignment: .bottomTrailing) {
                RoundedRectangle(cornerRadius: 17).fill(item.accent.gradient).frame(height: 190)
                    .overlay(Image(systemName: "play.rectangle.fill").font(.system(size: 45)).foregroundStyle(.white.opacity(0.85)))
                Text(item.duration).font(.caption2.bold()).padding(5).background(.black.opacity(0.75), in: RoundedRectangle(cornerRadius: 5)).padding(9)
            }
            HStack(alignment: .top) {
                Circle().fill(item.accent).frame(width: 36, height: 36).overlay(Text(String(item.channel.prefix(1))).bold())
                VStack(alignment: .leading, spacing: 3) {
                    Text(item.title).font(.subheadline.weight(.semibold)).foregroundStyle(.white).lineLimit(2)
                    Text("\(item.channel) · \(item.category)").font(.caption).foregroundStyle(.secondary)
                }
                Spacer(minLength: 0)
                if saved { Image(systemName: "bookmark.fill").foregroundStyle(.white) }
            }
        }
    }
}

private struct YouTubeWebView: UIViewRepresentable {
    let url: URL

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.allowsInlineMediaPlayback = true
        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.allowsBackForwardNavigationGestures = true
        webView.isOpaque = false
        webView.backgroundColor = .black
        webView.scrollView.backgroundColor = .black
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        guard webView.url != url else { return }
        webView.load(URLRequest(url: url))
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                     for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            guard navigationAction.targetFrame == nil else { return nil }
            webView.load(navigationAction.request)
            return nil
        }
    }
}

@MainActor private struct DemoPlayer: View {
    let video: FlowItem
    @ObservedObject var store: FlowLocalStore
    @Environment(\.dismiss) private var dismiss
    @State private var player: AVPlayer?
    @State private var isPlaying = false

    var body: some View {
        VStack(spacing: 18) {
            HStack { Button("Done") { player?.pause(); dismiss() }; Spacer(); Text("FLOW PLAYER").font(.caption.bold()); Spacer(); Image(systemName: "ellipsis") }.padding(.horizontal)
            if let player { VideoPlayer(player: player).frame(height: 235).clipShape(RoundedRectangle(cornerRadius: 15)) }
            else { RoundedRectangle(cornerRadius: 15).fill(video.accent.gradient).frame(height: 235).overlay(ProgressView()) }
            VStack(alignment: .leading, spacing: 9) {
                Text(video.title).font(.title3.bold())
                Text(video.channel).foregroundStyle(.secondary)
                HStack {
                    Button { store.recordLike(video) } label: { Label("Like", systemImage: "hand.thumbsup") }
                    Spacer()
                    Button { store.toggleSave(video) } label: { Label(store.savedItems.contains(video) ? "Saved" : "Save", systemImage: "bookmark") }
                    Spacer(); Label("Share", systemImage: "square.and.arrow.up")
                }.font(.subheadline).padding(.vertical, 10)
                Text("Demo stream only. This is not connected to Flow's YouTube extractor. Resolution, subtitles, download, PiP, SponsorBlock and casting are not yet ported.")
                    .font(.footnote).foregroundStyle(.secondary)
                Spacer()
                Button { if isPlaying { player?.pause() } else { player?.play(); store.recordWatch(video) }; isPlaying.toggle() } label: {
                    Label(isPlaying ? "Pause" : "Play", systemImage: isPlaying ? "pause.fill" : "play.fill")
                        .frame(maxWidth: .infinity).padding().background(Color.white, in: Capsule()).foregroundStyle(.black)
                }
            }.padding(.horizontal, 18)
            Spacer(minLength: 0)
        }.padding(.top, 14).foregroundStyle(.white)
        .onAppear {
            guard let url = URL(string: video.videoURL) else { return }
            let avPlayer = AVPlayer(url: url); player = avPlayer; avPlayer.play(); isPlaying = true; store.recordWatch(video)
        }
        .onDisappear { player?.pause() }
    }
}

private extension FlowItem {
    var accent: Color {
        switch category {
        case "Animation": .teal
        case "Technology": .indigo
        case "Nature": .green
        case "Music": .orange
        case "Art": .pink
        default: .blue
        }
    }
}
