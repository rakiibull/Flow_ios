import Foundation
import SwiftUI

struct FlowItem: Identifiable, Codable, Equatable {
    var id: Int
    var title: String
    var channel: String
    var duration: String
    var category: String
    var topicWeights: [String: Double]
    var isShort: Bool
    var videoURL: String

    static let samples: [FlowItem] = [
        .init(id: 1, title: "Big Buck Bunny — animated short film", channel: "Blender", duration: "10:34", category: "Animation", topicWeights: ["animation": 1.0, "film": 0.55, "blender": 0.3], isShort: false, videoURL: "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"),
        .init(id: 2, title: "A guide to creative coding", channel: "Creative Lab", duration: "12:08", category: "Technology", topicWeights: ["technology": 0.8, "coding": 1.0, "education": 0.45], isShort: false, videoURL: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4"),
        .init(id: 3, title: "A quiet walk through the forest", channel: "Open Nature", duration: "08:42", category: "Nature", topicWeights: ["nature": 1.0, "travel": 0.5, "relaxation": 0.35], isShort: false, videoURL: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4"),
        .init(id: 4, title: "How music changes the way we focus", channel: "Sound Mind", duration: "16:20", category: "Music", topicWeights: ["music": 1.0, "education": 0.5, "psychology": 0.5], isShort: false, videoURL: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4"),
        .init(id: 5, title: "One minute of satisfying pottery", channel: "Clay Days", duration: "00:58", category: "Art", topicWeights: ["art": 0.8, "craft": 1.0], isShort: true, videoURL: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4"),
        .init(id: 6, title: "Beginner guitar practice session", channel: "Sound Mind", duration: "09:12", category: "Music", topicWeights: ["music": 0.9, "guitar": 1.0, "education": 0.35], isShort: false, videoURL: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4")
    ]
}

struct FlowTopicScore: Identifiable {
    var topic: String
    var value: Double
    var id: String { topic }
}

private struct LocalProfile: Codable {
    var topicScores: [String: Double] = [:]
    var recentTopicScores: [String: Double] = [:]
    var savedIDs: Set<Int> = []
    var likedIDs: Set<Int> = []
    var queueIDs: [Int] = []
    var history: [Int: Date] = [:]
    var blockedTopics: Set<String> = []
    var blockedChannels: Set<String> = []
    var interactions: Int = 0
    var searchHistory: [String] = []

    private enum CodingKeys: String, CodingKey {
        case topicScores, recentTopicScores, savedIDs, likedIDs, queueIDs, history
        case blockedTopics, blockedChannels, interactions, searchHistory
    }

    init() {}

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        topicScores = try values.decodeIfPresent([String: Double].self, forKey: .topicScores) ?? [:]
        recentTopicScores = try values.decodeIfPresent([String: Double].self, forKey: .recentTopicScores) ?? [:]
        savedIDs = try values.decodeIfPresent(Set<Int>.self, forKey: .savedIDs) ?? []
        likedIDs = try values.decodeIfPresent(Set<Int>.self, forKey: .likedIDs) ?? []
        queueIDs = try values.decodeIfPresent([Int].self, forKey: .queueIDs) ?? []
        history = try values.decodeIfPresent([Int: Date].self, forKey: .history) ?? [:]
        blockedTopics = try values.decodeIfPresent(Set<String>.self, forKey: .blockedTopics) ?? []
        blockedChannels = try values.decodeIfPresent(Set<String>.self, forKey: .blockedChannels) ?? []
        interactions = try values.decodeIfPresent(Int.self, forKey: .interactions) ?? 0
        searchHistory = try values.decodeIfPresent([String].self, forKey: .searchHistory) ?? []
    }
}

/// Local-only prototype store. User activity is persisted in Application Support and is not uploaded.
@MainActor final class FlowLocalStore: ObservableObject {
    @Published private var profile: LocalProfile
    @Published var searchText = ""
    @Published var selectedCategory = "All"

    private let fileURL: URL
    private let libraryURL: URL

    init() {
        let root = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
            .appendingPathComponent("FlowLocal", isDirectory: true)
        try? FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        fileURL = root.appendingPathComponent("profile.json")
        libraryURL = root.appendingPathComponent("library.json")
        profile = (try? JSONDecoder().decode(LocalProfile.self, from: Data(contentsOf: fileURL))) ?? LocalProfile()
    }

    var rankedFeed: [FlowItem] {
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        return FlowItem.samples
            .filter { selectedCategory == "All" || $0.category == selectedCategory }
            .filter { query.isEmpty || $0.title.localizedCaseInsensitiveContains(query) || $0.channel.localizedCaseInsensitiveContains(query) }
            .filter { !profile.blockedTopics.contains($0.category.lowercased()) && !profile.blockedChannels.contains($0.channel) }
            .sorted { score($0) > score($1) }
    }

    var savedItems: [FlowItem] { FlowItem.samples.filter { profile.savedIDs.contains($0.id) } }
    var queueItems: [FlowItem] { profile.queueIDs.compactMap { id in FlowItem.samples.first { $0.id == id } } }
    var historyItems: [FlowItem] {
        profile.history.keys.sorted { (profile.history[$0] ?? .distantPast) > (profile.history[$1] ?? .distantPast) }
            .compactMap { id in FlowItem.samples.first { $0.id == id } }
    }
    var suggestedTopics: [FlowTopicScore] {
        profile.topicScores.sorted { $0.value > $1.value }.prefix(8).map { FlowTopicScore(topic: $0.key, value: $0.value) }
    }
    var recommendationMaturity: Double { min(Double(profile.interactions) / 40.0, 1.0) }

    func recordWatch(_ item: FlowItem, fraction: Double = 0.6) {
        profile.history[item.id] = Date()
        profile.interactions += 1
        let strength = min(max(fraction, 0.05), 1.0)
        learn(item.topicWeights, strength: strength)
        persist()
    }

    func recordLike(_ item: FlowItem) {
        profile.likedIDs.insert(item.id)
        profile.interactions += 1
        learn(item.topicWeights, strength: 1.0)
        persist()
    }

    func toggleSave(_ item: FlowItem) {
        if profile.savedIDs.contains(item.id) { profile.savedIDs.remove(item.id) }
        else { profile.savedIDs.insert(item.id); learn(item.topicWeights, strength: 0.35) }
        persist()
    }

    func addToQueue(_ item: FlowItem) {
        if !profile.queueIDs.contains(item.id) { profile.queueIDs.append(item.id); persist() }
    }

    func removeFromQueue(_ item: FlowItem) {
        profile.queueIDs.removeAll { $0 == item.id }
        persist()
    }

    func recordSkip(_ item: FlowItem) {
        profile.interactions += 1
        for (topic, weight) in item.topicWeights { profile.topicScores[topic] = max(0, (profile.topicScores[topic] ?? 0) - 0.08 * weight) }
        persist()
    }

    func blockTopic(_ item: FlowItem) {
        profile.blockedTopics.insert(item.category.lowercased())
        persist()
    }

    func blockChannel(_ item: FlowItem) {
        profile.blockedChannels.insert(item.channel)
        persist()
    }

    func clearProfile() {
        profile = LocalProfile()
        persist()
    }

    func exportProfile() -> URL? {
        try? JSONEncoder().encode(profile).write(to: libraryURL, options: .atomic)
        return FileManager.default.fileExists(atPath: libraryURL.path) ? libraryURL : nil
    }

    private func score(_ item: FlowItem) -> Double {
        if item.topicWeights.isEmpty || (profile.topicScores.isEmpty && profile.recentTopicScores.isEmpty) { return 0.3 + Double(abs(item.id * 1103515245 % 997)) / 997_000.0 }
        let longTerm = FlowContentVector(topics: profile.topicScores)
        let recent = FlowContentVector(topics: profile.recentTopicScores)
        let taste = FlowNeuroCore.blend(longTerm: longTerm, recent: recent)
        let content = FlowContentVector(topics: item.topicWeights)
        let similarity = FlowNeuroCore.similarity(taste, content)
        let recentPenalty = profile.history[item.id].map { Date().timeIntervalSince($0) < 86_400 ? 0.15 : 0 } ?? 0
        let discovery = 0.08 / (1 + similarity)
        return similarity + discovery - recentPenalty
    }

    private func learn(_ topics: [String: Double], strength: Double) {
        let video = FlowContentVector(topics: topics)
        let global = FlowNeuroCore.learn(current: FlowContentVector(topics: profile.topicScores), video: video, strength: strength, horizon: FlowNeuroCore.longTerm, scalarRate: 0.15 * strength)
        let recent = FlowNeuroCore.learn(current: FlowContentVector(topics: profile.recentTopicScores), video: video, strength: strength, horizon: FlowNeuroCore.recent, scalarRate: 0.15 * strength)
        profile.topicScores = global.topics
        profile.recentTopicScores = recent.topics
    }

    private func persist() {
        guard let data = try? JSONEncoder().encode(profile) else { return }
        try? data.write(to: fileURL, options: .atomic)
        objectWillChange.send()
    }
}
