/*
 * Adapted for the Flow iOS port from Flow Android Client's FlowNeuro vector mathematics.
 * Upstream: https://github.com/Flow-Tube/Flow
 * Copyright (C) 2025-2026 Flow | A-EDev
 *
 * This file is part of a GPLv3 derivative work. Preserve this attribution and license.
 */
import Foundation

struct FlowContentVector: Codable, Equatable {
    var topics: [String: Double] = [:]
    var duration: Double = 0.5
    var pacing: Double = 0.5
    var complexity: Double = 0.5
    var isLive: Double = 0
}

/// Swift port of the foundational vector operations used by FlowNeuro.
/// The full Android engine contains many additional models and ranking stages;
/// this file deliberately implements only these reusable core operations.
enum FlowNeuroCore {
    struct Horizon {
        let saturation: Double
        let halfLife: Double
        let maxTopics: Int
    }

    static let longTerm = Horizon(saturation: 30, halfLife: 600, maxTopics: 300)
    static let recent = Horizon(saturation: 3, halfLife: 25, maxTopics: 60)
    static let timeOfDay = Horizon(saturation: 30, halfLife: 600, maxTopics: 100)
    static let defaultRecentShare = 0.25
    private static let pruneThreshold = 0.005
    private static let maxWeight = 0.999999
    private static let phraseAbsorbRatio = 10.0
    private static let topicSimilarityWeight = 0.70
    private static let scalarOnlyDamp = 0.3

    /// Learns one positive interaction using FlowNeuro's saturating evidence update.
    static func learn(
        current: FlowContentVector,
        video: FlowContentVector,
        strength: Double,
        horizon: Horizon = longTerm,
        scalarRate: Double? = nil,
        protectedTopics: Set<String> = []
    ) -> FlowContentVector {
        let event = max(0, strength)
        let keep = pow(0.5, event / horizon.halfLife)
        var topics: [String: Double] = [:]
        for (key, weight) in current.topics {
            let decayed = 1 - pow(1 - min(weight, maxWeight), keep)
            if decayed >= pruneThreshold || video.topics[key] != nil { topics[key] = decayed }
        }
        for (key, share) in video.topics {
            let remaining = 1 - min(topics[key] ?? 0, maxWeight)
            topics[key] = 1 - remaining * exp(-event * share / horizon.saturation)
        }
        absorbPhraseWords(&topics, protected: protectedTopics)
        let rate = scalarRate ?? min(1, event * 0.15)
        func scalar(_ old: Double, _ target: Double) -> Double {
            min(max(old + (target - old) * rate * pow(1 - old, 2), 0), 1)
        }
        if topics.count > horizon.maxTopics {
            let ordered = topics.sorted { $0.value > $1.value }
            var kept = Dictionary(uniqueKeysWithValues: ordered.prefix(horizon.maxTopics).map { ($0.key, $0.value) })
            for (key, value) in ordered where protectedTopics.contains(stripDomain(key)) { kept[key] = value }
            topics = kept
        }
        return FlowContentVector(
            topics: topics,
            duration: scalar(current.duration, video.duration),
            pacing: scalar(current.pacing, video.pacing),
            complexity: scalar(current.complexity, video.complexity),
            isLive: scalar(current.isLive, video.isLive)
        )
    }

    /// Mixes long-term interests with recent-session interests, with recent topics at 25% weight.
    static func blend(longTerm: FlowContentVector, recent: FlowContentVector, recentShare: Double = defaultRecentShare) -> FlowContentVector {
        let recentMagnitude = sqrt(recent.topics.values.reduce(0) { $0 + $1 * $1 })
        guard recentMagnitude > 0 else { return longTerm }
        let longMagnitude = sqrt(longTerm.topics.values.reduce(0) { $0 + $1 * $1 })
        var topics: [String: Double] = [:]
        if longMagnitude > 0 {
            for (key, weight) in longTerm.topics { topics[key] = weight / longMagnitude * (1 - recentShare) }
        }
        for (key, weight) in recent.topics { topics[key, default: 0] += weight / recentMagnitude * recentShare }
        var result = longTerm
        result.topics = topics
        return result
    }

    /// Topic cosine weighted at 70%, plus duration/pacing/complexity similarity at 10% each.
    static func similarity(_ user: FlowContentVector, _ content: FlowContentVector) -> Double {
        let scalar = (1 - abs(user.duration - content.duration)) * 0.10
            + (1 - abs(user.pacing - content.pacing)) * 0.10
            + (1 - abs(user.complexity - content.complexity)) * 0.10
        guard !user.topics.isEmpty, !content.topics.isEmpty else { return scalar * scalarOnlyDamp }
        var dot = 0.0
        var intersection = false
        for (key, value) in user.topics {
            if let exact = content.topics[key] {
                dot += value * exact
                intersection = true
            } else if !key.contains(":"), let tagged = content.topics.first(where: { $0.key.hasPrefix(key + ":") })?.value {
                dot += value * tagged * 0.3
                intersection = true
            } else if key.contains(":"), let base = key.split(separator: ":", maxSplits: 1).first.map({ String($0) }), let untagged = content.topics[base] {
                dot += value * untagged * 0.3
                intersection = true
            }
        }
        guard intersection else { return scalar * scalarOnlyDamp }
        let a = sqrt(user.topics.values.reduce(0) { $0 + $1 * $1 })
        let b = sqrt(content.topics.values.reduce(0) { $0 + $1 * $1 })
        guard a > 0, b > 0 else { return scalar * scalarOnlyDamp }
        return dot / (a * b) * topicSimilarityWeight + scalar
    }

    static func titleSimilarity(_ lhs: Set<String>, _ rhs: Set<String>) -> Double {
        guard !lhs.isEmpty, !rhs.isEmpty else { return 0 }
        let intersection = lhs.intersection(rhs).count
        let union = lhs.union(rhs).count
        return union == 0 ? 0 : Double(intersection) / Double(union)
    }

    private static func absorbPhraseWords(_ topics: inout [String: Double], protected: Set<String>) {
        var strongestPhraseByWord: [String: Double] = [:]
        for (key, value) in topics {
            let base = stripDomain(key)
            if base.contains(" ") {
                for word in base.split(separator: " ").map(String.init) {
                    strongestPhraseByWord[word] = max(strongestPhraseByWord[word] ?? 0, value)
                }
            }
        }
        topics = topics.filter { key, weight in
            let base = stripDomain(key)
            return base.contains(" ") || protected.contains(key) || (strongestPhraseByWord[base] ?? 0) <= weight * phraseAbsorbRatio
        }
    }

    private static func stripDomain(_ topic: String) -> String {
        guard let separator = topic.firstIndex(of: ":") else { return topic }
        return String(topic[..<separator])
    }
}
