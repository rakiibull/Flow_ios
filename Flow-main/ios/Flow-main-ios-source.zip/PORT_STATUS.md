# Flow iOS port status

This is an in-progress native port scaffold, not a feature-complete app. The existing Android app remains unchanged; iOS sources live in `ios/`.

## Implemented in the current prototype

- SwiftUI navigation for Home, Shorts, Music, Subscriptions, and Library.
- Native in-app YouTube search results as Flow-style cards, retrieved through YouTube Data API v3, with playback in YouTube's embedded player. A user-supplied API key is required and saved on-device.
- Demo catalog with category filters, search, a sample AVPlayer view, and context actions.
- Local save/favorite state, watch history, topic/channel hiding, likes, skips, and a persistent music queue.
- Swift adaptation of FlowNeuro's foundational topic-vector learning with long/recent horizons, phrase absorption, vector blend, weighted cosine similarity, and title overlap. Local watch/like/save signals update the vectors and rank demo items. This is only a subset of FlowNeuro, not parity with the full engine.
- Local JSON storage in Application Support, profile summary, export/share, and reset controls.
- XcodeGen project definition and GitHub Actions configuration for an unsigned iOS Simulator build artifact.

## Still required for Flow feature parity

1. Replace the sample home catalogue with a native Flow/YouTube feed and user-controlled channel/subscription source. Current in-app API search is native-card based but is not a home feed and requires the user's YouTube Data API key. The Android NewPipe Extractor cannot be imported directly into the Swift target.
2. Continue porting and test the full FlowNeuro engine, including its tokenizer/language rules, all interaction weights, time-of-day profiles, rejection memory, freshness/repetition controls, diversification, import/export, and dashboard. The current vector operations are only a foundation.
3. Build persistent production models and migrations for channels, subscriptions, playlists, history, and downloads.
4. Implement AVPlayer/AVAudioSession playback lifecycle, media controls, queue reorder, shuffle/repeat, lyrics, subtitle selection, resolution options, picture-in-picture, and background audio.
5. Port or replace SponsorBlock, DeArrow, Return YouTube Dislike, casting, and download/format selection with iOS-compatible code and service contracts.
6. Implement onboarding, all theme variants, privacy controls, data import/export, accessibility, localization, and error handling.
7. Add unit/UI tests and perform real-device playback, performance, privacy, and compatibility checks.
8. Build and sign on macOS/Xcode. The current workflow only creates a simulator artifact; it cannot install on an iPhone.

## Build status

No Xcode compile has been run in the current Linux environment. The files are prepared for a macOS CI runner, but compilation errors may remain until the first XcodeGen/Xcode build. The CI job must be run after this folder and root workflow are pushed to a GitHub repository. A simulator `.app` artifact is not installable on an iPhone.

## License

The parent Flow source is GPLv3. Preserve GPLv3 licensing and Flow attribution for derivative work, and check the licenses of any added dependencies before distribution. Upstream project: https://github.com/Flow-Tube/Flow.
