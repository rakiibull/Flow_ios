# Windows থেকে iOS prototype build করানো

Windows-এ source code ও Git পরিচালনা করা যাবে। iOS compile Windows-এ হয় না; এই project-এর workflow GitHub-এর macOS runner ব্যবহার করে **unsigned Simulator build** বানায়। এতে iPhone-এ ইনস্টলযোগ্য `.ipa` হয় না।

## ১. ZIP ও script একই folder-এ রাখুন

`Flow-main-with-ios-prototype.zip` এবং আলাদা `Push-Private-GitHub.ps1` download করে Windows PC-তে একই folder-এ রাখুন। PowerShell খুলে ওই folder-এ যান।

## ২. Git ও GitHub CLI ইনস্টল/সাইন-ইন

Git for Windows এবং GitHub CLI (`gh`) ইনস্টল করুন। তারপর PowerShell-এ চালান:

```powershell
gh auth login
gh auth status
```

Login সফল হলে নিচের script চালান:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\Push-Private-GitHub.ps1 -RepositoryName "Flow-iOS"
```

Script ZIP extract করে source repository-টি **private** হিসেবে তৈরি ও push করবে। এটি সম্পূর্ণ source-এ commit বানাবে; Git-এর `user.name` ও `user.email` আগে সেট না থাকলে script জিজ্ঞেস করবে। আপনার source বা credentials এখানে chat-এ পাঠাতে হবে না।

## ৩. macOS cloud build দেখুন

Push হওয়ার পর GitHub-এ নতুন private repository খুলে **Actions** tab-এ যান। `iOS prototype build` workflow শেষ হলে run-এর **Artifacts** অংশ থেকে `Flow-iOS-Simulator-only` নামের artifact নামানো যাবে। Workflow-এর প্রথম run GitHub-এ অনুমোদন চাইলে সেটি enable করুন। Build fail করলে Actions-এর log থেকে error নিয়ে code ঠিক করতে হবে; বর্তমান sandbox-এ Xcode নেই বলে আগে compile-verify করা যায়নি।

## iPhone-এ ব্যবহার করার জন্য যা বাকি

Simulator artifact iPhone-এ install হয় না। Device build-এর জন্য Apple signing certificate/provisioning এবং macOS runner-এ secret-ভিত্তিক signing/export workflow আলাদা করে সেট করতে হবে; iPhone-এর UDID, Apple account/team setup ও signing entitlement লাগতে পারে। Signing-এর কোনো secret Git repository-তে commit করবেন না। বর্তমান project-এ real YouTube/Flow data source, পূর্ণ FlowNeuro engine এবং Android-এর সব player/download/music integration-ও এখনো port হয়নি—তাই signed হলেও এটি এখনই full-feature Flow app নয়।
