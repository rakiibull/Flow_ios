# Flow iOS — initial native prototype

This directory is the beginning of a SwiftUI iOS implementation. The Android app is not cross-platform, so this is a new iOS target rather than a conversion of the Android APK. The parent Flow project is GPLv3; retain its license and attribution when modifying or distributing this derivative project. Upstream: https://github.com/Flow-Tube/Flow.

## Included in this first scaffold

- SwiftUI app shell with Home, Shorts, Music, Subscriptions, and Library tabs.
- In-app YouTube search and viewing through YouTube's mobile website in WKWebView. Search results and playback are served directly by YouTube; this is a practical browsing path, not a native Flow video feed or NewPipeExtractor port.
- Searchable demo feed with local category selection, save/like/skip and block-topic/block-channel actions, persisted watch history and saved videos.
- A demo player using AVPlayer and a public sample video URL.
- Local-only Application Support JSON profile, export/share and reset controls, plus Swift ports of FlowNeuro's foundational topic vectors, long/recent horizon learning, phrase absorption, similarity and blend operations. The profile uses those operations to rank demo items.
- XcodeGen project definition and a GitHub Actions workflow that builds an unsigned iOS Simulator app on macOS.

## Not yet ported

This is not feature parity and is not a signed IPA. The native feed still uses demo items; YouTube results open in the in-app YouTube browser instead of appearing as native Flow cards. The prototype has no NewPipeExtractor equivalent, full FlowNeuro ranker and learning pipeline, channel/subscription backend, real music-service queue or lyrics, download manager, SponsorBlock, DeArrow, RYD, casting, subtitles, PiP/background audio configuration, playback resolution controls, NewPipe import, or complete theme system. Those features require separate iOS designs, compatible libraries/services, implementation, and testing on actual devices.

## Generate and build on macOS

Install Xcode and XcodeGen, then from this directory run:

```sh
xcodegen generate
xcodebuild -project FlowiOS.xcodeproj -scheme FlowiOS -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' CODE_SIGNING_ALLOWED=NO build
```

The included GitHub Actions workflow performs a simulator build. It does not sign or install the app on an iPhone. Installing on a personal iPhone needs Apple signing in Xcode or another macOS signing environment. Never commit signing certificates or private keys to this repository.
