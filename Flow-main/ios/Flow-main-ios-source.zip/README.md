# Flow iOS — initial native prototype

This directory is the beginning of a SwiftUI iOS implementation. The Android app is not cross-platform, so this is a new iOS target rather than a conversion of the Android APK. The parent Flow project is GPLv3; retain its license and attribution when modifying or distributing this derivative project. Upstream: https://github.com/Flow-Tube/Flow.

## Included in this first scaffold

- SwiftUI app shell with Home, Shorts, Music, Subscriptions, and Library tabs.
- Native in-app YouTube search results using the official YouTube Data API v3, with video playback through YouTube's embedded player. Search results appear as Flow video cards rather than YouTube's search website.
- Searchable demo feed with local category selection, save/like/skip and block-topic/block-channel actions, persisted watch history and saved videos.
- A demo player using AVPlayer and a public sample video URL.
- Local-only Application Support JSON profile, export/share and reset controls, plus Swift ports of FlowNeuro's foundational topic vectors, long/recent horizon learning, phrase absorption, similarity and blend operations. The profile uses those operations to rank demo items.
- XcodeGen project definition and a GitHub Actions workflow that builds an unsigned iOS Simulator app on macOS.

## Not yet ported

This is not feature parity and is not a signed IPA. To search, the user must provide a Google Cloud API key with YouTube Data API v3 enabled; the app stores the key locally on the device. Playback uses YouTube's official embedded player, so some videos may be unavailable for embedding and YouTube controls/branding remain visible. The main Home feed still contains demo items. The prototype has no native NewPipeExtractor-equivalent feed, full FlowNeuro ranker and learning pipeline, channel/subscription backend, real music-service queue or lyrics, download manager, SponsorBlock, DeArrow, RYD, casting, subtitles, PiP/background audio configuration, playback resolution controls, NewPipe import, or complete theme system. Those features require separate iOS designs, compatible libraries/services, implementation, and testing on actual devices.

### Enable YouTube search

In Google Cloud Console, create or select a project, enable **YouTube Data API v3**, and create an API key. Restrict the key to the YouTube Data API and to the iOS app bundle ID `org.flowtube.flow.ios`. In Flow, open Settings and paste the key into the YouTube API field. The key is saved in this app's local settings and is not committed into the public source repository. API key restrictions reduce misuse, but a key embedded in a client app should still be treated as discoverable.

## Generate and build on macOS

Install Xcode and XcodeGen, then from this directory run:

```sh
xcodegen generate
xcodebuild -project FlowiOS.xcodeproj -scheme FlowiOS -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' CODE_SIGNING_ALLOWED=NO build
```

The included GitHub Actions workflow performs a simulator build. It does not sign or install the app on an iPhone. Installing on a personal iPhone needs Apple signing in Xcode or another macOS signing environment. Never commit signing certificates or private keys to this repository.
